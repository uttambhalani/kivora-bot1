
const venom = require('venom-bot');

venom
  .create({
    session: 'kivora-session',
  })
  .then((client) => start(client))
  .catch((erro) => {
    console.log(erro);
  });

function start(client) {
  client.onMessage((message) => {
    const msg = message.body.toLowerCase();

    // 👋 Greeting and menu
    if (msg === 'hi' || msg === 'hello' || msg.includes('menu')) {
      client.sendText(
        message.from,
        `🙏 Thanks for messaging KIVORA™️! 💫

Welcome to your stylish home & self-care destination 🏠🧺👗

👇 Please choose an option:
1️⃣ Order Info  
2️⃣ Track Order  
3️⃣ Visit Website  
4️⃣ Follow us on Instagram  
0️⃣ Exit Chat  

🛒 www.shopkivora.in`
      );
      setTimeout(() => {
        client.sendText(
          message.from,
          `🎁 Get ₹50 Cashback or ₹50 OFF your next order!

Just follow these steps:
1️⃣ Order any product from KIVORA  
2️⃣ Share product photo + video review  
3️⃣ Mention us on Instagram: @shopkivora  
4️⃣ Claim your offer! (Only one offer applicable)

🔥 Surprise your friends with our products too!`
        );
      }, 2500);
    }

    // 1️⃣ Order Info
    if (msg === '1') {
      client.sendText(
        message.from,
        '📝 To place a new order, visit:
👉 www.shopkivora.in'
      );
    }

    // 2️⃣ Track Order
    if (msg === '2') {
      client.sendText(
        message.from,
        '📦 Track your order here:
👉 www.shopkivora.in/track'
      );
    }

    // 3️⃣ Visit Website
    if (msg === '3') {
      client.sendText(
        message.from,
        '🌐 Visit our official website:
👉 www.shopkivora.in'
      );
    }

    // 4️⃣ Instagram link
    if (msg === '4') {
      client.sendText(
        message.from,
        '📸 Follow us on Instagram:
👉 https://www.instagram.com/shopkivora'
      );
    }

    // 0️⃣ Exit Chat
    if (msg === '0') {
      client.sendText(
        message.from,
        `👋 You’ve exited the chat with KIVORA™️

🙏 Thank you for visiting us!  
We’re always here with premium home & innerwear essentials 🛍️

📞 Got questions later?  
Just say "Hi" — we’ll be here 💬

💡 Follow us here for daily offers & trends:  
👉 https://www.instagram.com/shopkivora`
      );
    }
  });
}
